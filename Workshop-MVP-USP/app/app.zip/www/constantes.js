/**
*   Arquivo com constantes
**/

/**
*   Ambiente - Comentar o que nao esta sendo usado
**/
// var ambiente = 'http://localhost/formiga/' // Dev
var ambiente = 'http://www.formiga.info/' // Prod

/**
*   URLs para as requisicoes
**/
var host = ambiente + 'server/requisicoes.php'
var imagens = ambiente + 'server/uploads/'

/**
*   Nomes dos servicos para noticias
**/
var func_listar_noticias = 'listar_noticias'

<?php get_header(); ?>
<div class="conteudo">
	<main>
		<section class="slide container">Slide</section>
		<section class="servicos container">Serviços</section>
		<section class="meio container">
			<div class="row">
				<aside class="barra-lateral col-md-3">Barra Lateral</aside>
				<div class="noticias col-md-9">
				<p>Esta será a área de notícias da página home</p>

				</div>
			</div>
		</section>
		<section class="mapa container">Mapa</section>
	</main>	
</div>
<?php get_footer(); ?>

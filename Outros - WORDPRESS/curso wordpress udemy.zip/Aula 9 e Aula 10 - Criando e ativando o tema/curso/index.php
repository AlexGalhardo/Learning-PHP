<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Curso WordPress</title>
</head>
<body>
	<p>Este é um parágrafo</p>
</body>
</html>
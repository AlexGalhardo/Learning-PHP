<article>
	<h1 class="vermelho"><?php the_title(); ?></h1>
	<p>Categorias: <?php the_category(' '); ?></p>
	<p><?php the_content(); ?></p>
</article>
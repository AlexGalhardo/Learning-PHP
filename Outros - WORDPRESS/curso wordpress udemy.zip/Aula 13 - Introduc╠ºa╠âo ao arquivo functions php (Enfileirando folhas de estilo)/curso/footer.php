<footer>
	<p>Rodapé</p>
</footer>

</body>
</html>
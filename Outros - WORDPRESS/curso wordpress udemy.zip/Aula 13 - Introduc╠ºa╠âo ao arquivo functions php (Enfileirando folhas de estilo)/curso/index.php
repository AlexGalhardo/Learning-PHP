<?php get_header(); ?>
<div class="conteudo">
	<main>
		<section class="slide">Slide</section>
		<section class="servicos">Serviços</section>
		<section class="meio">
			
			<aside class="barra-lateral">Barra Lateral</aside>
			<div class="noticias">Noticias</div>
		</section>
		<section class="mapa">Mapa</section>
	</main>	
</div>
<?php get_footer(); ?>

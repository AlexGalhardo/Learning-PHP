<article class="post-format-image">
	<h1><?php the_title(); ?></h1>
	<p>Categorias: <?php the_category(' '); ?></p>
	<p><?php the_content(); ?></p>
</article>
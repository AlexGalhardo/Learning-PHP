<footer>
	<p>Rodapé</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
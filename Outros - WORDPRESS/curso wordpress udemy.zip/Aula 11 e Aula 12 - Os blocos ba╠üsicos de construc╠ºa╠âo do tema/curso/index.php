<?php get_header(); ?>
<div class="conteudo">
	<main>
		<section class="slide"></section>
		<section class="servicos"></section>
		<section class="meio">
			
			<aside class="barra-lateral"></aside>
			<div class="noticias"></div>
		</section>
		<section class="mapa"></section>
	</main>	
</div> 
<?php get_footer(); ?>

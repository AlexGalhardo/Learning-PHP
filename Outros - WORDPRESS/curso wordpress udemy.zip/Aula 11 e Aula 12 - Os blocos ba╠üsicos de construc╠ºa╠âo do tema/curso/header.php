<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Curso WordPress</title>
</head>
<body <?php body_class(); ?>>
	<p>Este é um parágrafo</p>

<header>
	<div class="barra-topo">
		<div class="redes-sociais"></div>
		<div class="pesquisa"></div>

	</div>

	<div class="area-menu">
		<div class="logo"></div>
		<div class="menu"></div>
	</div>
	
</header>